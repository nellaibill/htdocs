<?php
$connection = new mysqli("localhost", "root", "", "expensemgmt") or die(mysqli_error());
?>