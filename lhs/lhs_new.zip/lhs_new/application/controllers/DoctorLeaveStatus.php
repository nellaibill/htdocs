<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DoctorLeaveStatus extends CI_Controller {
public function __construct()
	{
		parent::__construct();

		/*load database libray manually*/
		$this->load->database();
		$this->load->library('session');
		/*load Model*/
		$this->load->helper('url');
        if(!$this->session->userdata('user_data_session')){
            redirect('Login');
        }
		$this->load->model('DoctorLeaveStatusModel','DoctorLeaveStatus');
		}
	public function index()
	{
		$this->load->view('header');
		$this->load->view('doctor_view');
		$this->load->view('footer');
	}

	public function ajax_list()
	{
		$list = $this->DoctorLeaveStatus->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $doctor) {
			$no++;
			$row = array();
			$row[] = $doctor->date;
			$row[] = $doctor->status;
			$row[] = $doctor->remarks;
			$row[] = $doctor->updated_on;
						//add html for action
						$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_leave('."'".$doctor->doctor_availability_id."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
						<a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_leave('."'".$doctor->doctor_availability_id."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';
			$data[] = $row;	
		}
		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->DoctorLeaveStatus->count_all(),
						"recordsFiltered" => $this->DoctorLeaveStatus->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}
	public function ajax_edit($id)
	{
		$data = $this->DoctorLeaveStatus->get_by_id($id);
	//	$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
		echo json_encode($data);
	}

	public function ajax_add()
	{
		$this->_validate();
		$date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
		$xCreatedOn=$date->format('Y-m-d H:i:s');
		$data = array(
				'doctor_id' => $this->input->post('doctor_id'),
				'date' => $this->input->post('transaction_date'),
				'status' => $this->input->post('status'),
				'remarks' => $this->input->post('remarks'),
				'created_on' => $xCreatedOn,
				'updated_on' => $xCreatedOn,
			);
			if($this->DoctorLeaveStatus->check_id_exists
			($this->input->post('doctor_id'),$this->input->post('transaction_date')) ==0)
			{ 
		      $insert = $this->DoctorLeaveStatus->save($data);
		      echo json_encode(array("status" => TRUE));
			}
			else
			{
				return;
			}
	}

	public function ajax_update()
	{
		$this->_validate();
		$date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
		$xUpdatedOn=$date->format('Y-m-d H:i:s');
		$data = array(
			'status' => $this->input->post('status'),
			'remarks' => $this->input->post('remarks'),
			'updated_on' => $xUpdatedOn,
			);
				$this->DoctorLeaveStatus->update(array('doctor_availability_id' => $this->input->post('doctor_availability_id')), $data);
				echo json_encode(array("status" => TRUE));	
	}

	public function ajax_delete($id)
	{
		$this->DoctorLeaveStatus->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('transaction_date') == '')
		{
			$data['inputerror'][] = 'transaction_date';
			$data['error_string'][] = 'Date is required';
			$data['status'] = FALSE;
		}

		if($this->input->post('status') == '')
		{
			$data['inputerror'][] = 'status';
			$data['error_string'][] = 'Status is required';
			$data['status'] = FALSE;
		}
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}

	}

}
