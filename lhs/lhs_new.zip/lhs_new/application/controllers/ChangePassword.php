<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ChangePassword extends CI_Controller {
    public function __construct()
	{
		/*call CodeIgniter's default Constructor*/
		parent::__construct();
		/*load database libray manually*/
		$this->load->database();
		$this->load->library('session');
        $this->load->helper('url');
        if(!$this->session->userdata('user_data_session')){
            redirect('Login');
        }
		/*load Model*/
		
		$this->load->model('ChangePasswordModel');
	}       
	public function index()
	{
		$this->load->view('header');
		$this->load->view('change_password');
		$this->load->view('footer');
		if($this->input->post('save'))
		{
			$old_pass=$this->input->post('old_password');
			$new_pass=$this->input->post('new_password');
			$confirm_pass=$this->input->post('confirm_password');
			$data = $this->ChangePasswordModel->fetch_pass();
			if($data->password!=$old_pass)
			{
				echo "Old Password not matched!";
				return;
			}
			if((!strcmp($new_pass, $confirm_pass)))
			{
				$this->ChangePasswordModel->change_pass($new_pass);
				echo "Password changed successfully !";
			}
			else
			{
				echo "Invalid";
			}
		}
	}
}

?>
