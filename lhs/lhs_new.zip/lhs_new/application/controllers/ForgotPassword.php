<?php
class ForgotPassword extends CI_Controller
{
    public function __construct()
    {
        /*call CodeIgniter's default Constructor*/
        parent::__construct();
        /*load database libray manually*/
        $this->load->database();
        $this->load->library('session');
        /*load Model*/
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->model('ForgotPasswordModel');
    }
    public function index()
    { 

       $this->load->view('view_forgot_password');
      // $this-> check_forgot_password_mobile();
        
    }
    public function check_forgot_password()
    {
    
        $data = new stdClass();
        if ($this->input->post('save')) {
            // $this->load->helper('email');
            //$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean');
            $email = $this->input->post('email');
            if ($this->ForgotPasswordModel->check_email($email)) {
                $user_data = $this->ForgotPasswordModel->get_user_data($email);
                $xPassword = $user_data['password'];
                
                $config = Array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'ssl://smtp.googlemail.com',
                    'smtp_port' => 465,
                    'smtp_user' => 'nellaibill@gmail.com',
                    'smtp_pass' => 'Hana#2017',
                    'mailtype' => 'html',
                    'charset' => 'iso-8859-1'
                );
                $this->load->library('email', $config);
                $this->email->set_newline("\r\n");
                $this->email->from('nellaibill@gmail.com');
                $this->email->to($email);
                $this->email->subject('Lakshmi Hospital Login Password');
                $this->email->message('Your Password is .' . $xPassword);
                
                if (!$this->email->send()) {
                    $data->error = 'Email Fail to sent.';
                } else {
                    $data->error = 'Password sent to your email.';
                }
                $this->load->view('view_forgot_password', $data);
                
                
                // echo $this->email->print_debugger();
                
            } else {
                // login failed
                $data->error = 'Wrong Email.';
                // send error to the view
                $this->load->view('view_forgot_password', $data);
            }       
        }
    }

    public function check_forgot_password_mobile()
    {

	// Authorisation details.
	$username = "mdsaleem1804@gmail.com";
	$hash = "767cd45d8ee119179788ce7ac503b14e9478e345";
	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "PROSAV"; // This is who the message appears to be from.
	$numbers = "9578795653"; // A single number or a comma-seperated list of numbers
	$message = "This is a test message from the PHP API script.";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	echo $data;
    $ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);
    }

}
?>
