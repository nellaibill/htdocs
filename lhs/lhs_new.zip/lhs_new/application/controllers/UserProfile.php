<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserProfile extends CI_Controller {
    public function __construct()
	{
		/*call CodeIgniter's default Constructor*/
		parent::__construct();
		/*load database libray manually*/
		$this->load->database();
		$this->load->library('session');
		/*load Model*/
		$this->load->helper('url');
		$this->load->model('UserProfileModel');
	}       
	public function index()
	{
		$data['query']= $this->UserProfileModel->get_by_id();
		$this->load->view('header');
		$this->load->view('user_profile',$data);
		$this->load->view('footer');
    }
}
