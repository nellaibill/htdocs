
<div class="container">
<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li class="active">
						My Profile
						</li>
					</ol>
				</div>
			</div>

   
    <?php foreach($query as $row){ ?>

<table class="table table-bordered table-striped">

    <tbody>
      <tr>
      <td>Name </td>
        <td><?=$row->name;?></td>
      </tr>
      <tr>
        <td>Email </td>
        <td><?=$row->email;?></td>
      </tr>
      <tr>
        <td>Mobile </td>
        <td><?=$row->mobile;?></td>
      </tr>
      <tr>
        <td>Address </td>
        <td><?=$row->address;?></td>
      </tr>
      <tr>
        <td>User Name </td>
        <td><?=$row->username;?></td>
      </tr>
      <tr>
      <td>Password </td>
        <td><?=$row->password;?></td>
      </tr>
      <tr>
      <td>Status </td>
        <td><?=$row->status;?></td>
      </tr>
   
    </tbody>
  </table>
  <?php } ?>
  </div>
