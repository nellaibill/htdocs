<?php defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>Login Page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/tcss/style.css" rel="stylesheet">
    <script src="<?php echo base_url();?>assets/jquery/jquery-2.1.4.min.js"></script>
    <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
</head>
<body>


    <div class="container">
        <div class="card card-container">
         <h3>FORGOT PASSWORD ? </h3>

		<?php echo (!empty($error) ? '<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'.$error.'</p>' : ''); ?>
	 <form  action="<?php echo base_url(); ?>ForgotPassword/check_forgot_password" method="post">
		    <label>Enter Your Registerd - Email</label>
                <input type="text" value="" class="form-control" 
                name="email" > 
		       <br>
            <input type="submit" name="save" class="btn btn-primary"  value="Send Email"><br><br>
</form>
 <form  action="<?php echo base_url(); ?>ForgotPassword/check_forgot_password" method="post">
        <!--    	    <label>Enter Your Registerd - Mobile No</label>
                <input type="text" value="" class="form-control" 
                name="mobile" required> 

		       <br>
            <input type="submit" name="save" class="btn btn-primary"  value="Send OTP">!-->
</form>
  <a href="<?php echo base_url(); ?>Login">Login</a>

		</div>  
	</div>

</body>
</html>

