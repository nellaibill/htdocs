
<div class="container">

        <div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						<li class="active">
						Change Password
						</li>
					</ol>
				</div>
			</div>
<form method="post" >

	<div class="row">
		<div class="col-sm-4">
		    
		    <label>Current Password</label>
		    <div class="form-group pass_show"> 
                <input type="password" value="" class="form-control" 
                name="old_password" required> 
            </div> 
		       <label>New Password</label>
            <div class="form-group pass_show"> 
                <input type="password" value="" class="form-control" 
                name="new_password" required> 
            </div> 
		       <label>Confirm Password</label>
            <div class="form-group pass_show"> 
                <input type="password" value="" class="form-control" 
                 name="confirm_password" required> 
            </div> 
            <input type="submit" name="save" class="btn btn-primary"  value="Save Data">
		</div>  
	</div>
</form>
</div>
