<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UserProfileModel extends CI_Model {

	var $table = 'users';
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
    }
    public function get_by_id()
	{
       $this->load->library('session');
		$user_detail = $this->session->userdata('user_data_session');
		$user_id = $user_detail['id'];
		$this->db->from($this->table);
		$this->db->where('id',$user_id);
		$query = $this->db->get();
        return $query->result();
	}
}
?>