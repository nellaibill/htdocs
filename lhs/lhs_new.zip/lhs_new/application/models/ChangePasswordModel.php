<?php
class ChangePasswordModel extends CI_Model 
{
	var $table = 'users';
	function fetch_pass()
	{
		$this->load->library('session');
		$user_detail = $this->session->userdata('user_data_session');
		$user_id = $user_detail['id'];

		$this->db->from($this->table);
		$this->db->where('id',$user_id);
		$query = $this->db->get();
		return $query->row();
	}
	function change_pass($new_pass)
	{
		$this->load->library('session');
		$user_detail = $this->session->userdata('user_data_session');
		$user_id = $user_detail['id'];
	    $update_pass=$this->db->query("UPDATE users set password='$new_pass'  where id='$user_id'");
	}
}
?>
