<?php
class ForgotPasswordModel extends CI_Model 
{
	var $table = 'users';

	function check_email($email) {
		
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('email', $email);
		$query = $this->db->get()->row();		
		if (!empty($query)) {
			return true;
		} else {
			return false;
		}
	}
	
	function get_user_data($username) {
		
		//$this->load->library('session');
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('email', $username);	
		$query = $this->db->get();
		
		$user_data = array(
			'id'	=> $query->row('id'),
			'username'	=> $query->row('username'),
			'status'	=> $query->row('status'),
			'name'	=> $query->row('name'),
			'level'	=> $query->row('level'),
			'email'	=> $query->row('email'),
            'password'	=> $query->row('password')
			);
		
		return $user_data;
		
	}
}
?>
