<?php

	$con = mysqli_connect('localhost', 'lakshmih_admin', 'admin', 'lakshmih_daybook') 
	or die(mysql_error());


?>