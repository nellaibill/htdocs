<?php
require_once('session.php');
?>

<form action='loginform.php' method='POST'>
	<input type='text' name='user' />
	<input type='password' name='pass' />
	<input type='submit' name='sentForm' />
</form>