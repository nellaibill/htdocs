<script type="text/javascript">
function confirm_edit() {
  return confirm('Would you Like to Edit ?');
}
</script>
<script type="text/javascript">
function confirm_delete() {
  return confirm('Would you Like to Delete ?');
}
</script>