
<?php
header("Content-Type:application/json");
	include('db.php');
	$result = mysqli_query(
	$con,
	"select * from m_patientregistration");
	while ($row = mysqli_fetch_array($result)) {
	$row = mysqli_fetch_array($result);
	
		$response['uhid'] = $row['pat_unique_id'];
	$response['patient_name'] = $row['pat_name'];
	$response['patient_gender'] = $row['pat_gender'];
	$response['patient_dob'] = $row['pat_dob'];
	$response['patient_address'] = $row['pat_address'];
	$response['patient_mobile_no'] = $row['pat_mobile_no'];
	
		$json_response = json_encode($response);
	echo $json_response;

	mysqli_close($con);
	}
?>
             