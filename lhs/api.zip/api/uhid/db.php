<?php
$con = mysqli_connect("localhost","lakshmih_admin","admin","lakshmih_daybook");
    if (mysqli_connect_errno()){
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	die();
	}
	?>