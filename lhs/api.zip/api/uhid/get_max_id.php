
<?php
header("Content-Type:application/json");

	include('db.php');

	$result = mysqli_query(
	$con,
	"select count(1)+1  as maxuhid from uhid ");
	if(mysqli_num_rows($result)>0){
	$row = mysqli_fetch_array($result);
	$amount = $row['maxuhid'];
	response($order_id, $amount);
	mysqli_close($con);
	}else{
		response(NULL, NULL, 200,"No Record Found");
		}

 
function response($order_id,$amount){
	$response['maxuhid'] = $amount;
	$json_response = json_encode($response);
	echo $json_response;
}
?>
             