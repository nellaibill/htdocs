
<?php
header("Content-Type:application/json");
	include('db.php');
$xUhid=$_GET['uhid'];
	$result = mysqli_query(
	$con,
	"select * from m_patientregistration where pat_unique_id='$xUhid'");
	if(mysqli_num_rows($result)>0){
	$row = mysqli_fetch_array($result);
	$response['uhid'] = $row['pat_unique_id'];
	$response['patient_name'] = $row['pat_name'];
	$response['patient_gender'] = $row['pat_gender'];
	$response['patient_dob'] = $row['pat_dob'];
	$response['patient_address'] = $row['pat_address'];
	$response['patient_mobile_no'] = $row['pat_mobile_no'];
	
		$json_response = json_encode($response);
	echo $json_response;

	mysqli_close($con);
	}else{
		response(NULL, NULL, 200,"No Record Found");
		}
?>
             