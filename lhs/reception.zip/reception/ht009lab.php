<?php
include 'globalfile.php';
?>
<marquee bgcolor=orange width=100% height=75 direction=right behavior=alternate scrollamount=5> <font size="10" color="GREEN">LAB BILLING WORK IN PROGRESS!</font></marquee>