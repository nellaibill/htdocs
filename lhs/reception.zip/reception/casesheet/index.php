<marquee bgcolor="#66CD00"></marquee>
<?php

include('globalfile.php');
/* Display's today's date  data's only  */

$xFromDate=$GLOBALS ['xCurrentDate'];
$xToDate=$GLOBALS ['xCurrentDate'];




?>                  

  
<html>
<title>HOME-PAGE</title>
</html>

