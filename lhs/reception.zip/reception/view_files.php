<?php
//include 'menu1.php';
?>

<div class="container">
  <div class="row">
<iframe width="100%" height ="100%" src="http://technicalhspt.org/reception/filemanagementsystem/report.php"></iframe>
  </div>
  
  </div>