<?php
include 'globalfunctions.php';
include 'global_configfunctions.php';
include 'menu1.php';
include '../session.php';
?>