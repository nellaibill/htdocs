<?php
include 'globalfunctions.php';
include 'menu.php';
?>