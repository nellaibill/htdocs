<?php
include 'menu.php';
?>
<body background="images/hrm.png">
</body>