<!DOCTYPE html>
<html lang="en">
<head>
<title>Employer</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>

	<nav class="navbar navbar-inverse">
		<div class="container-fluid">

			<ul class="nav navbar-nav">


				<li><a href="employee_salary.php">SALARY-ENTRY</a></li>
	<li><a href="report1.php">REPORT-VIEW</a></li>
<li><a href="" onclick="PrintDiv(); return false">PRINT <span class="glyphicon glyphicon-print" style="color:yellow" ></span></a></li>
				<!-- 				
				<li><a href="settings.php">SETTINGS</a></li>
				<li><a href="employer.php">Employer</a></li>
				 -->


			</ul>
		</div>
	</nav>


</body>
</html>

