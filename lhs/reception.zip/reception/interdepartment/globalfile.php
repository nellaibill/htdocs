<?php
include '../../session.php';
include 'globalfunctions.php';
include 'menu.php';


?>
<!-- Sweet Alert Linking Files 
 <script src="js/sweetalert-dev.js"></script>
 <link rel="stylesheet" href="css/sweetalert.css">


 Sweet Alert Linking Files Ended!-->


 <script type="text/javascript">     
function RefreshPage() {
    location.reload();
}
function confirm_edit() {
  return confirm('Would you Like to Edit ?');
}
function confirm_confirm() {
  return confirm('Would you Like to Confirm?');
}
function confirm_delete() {
  return confirm('Would you Like to Delete ?');
}


</script>
