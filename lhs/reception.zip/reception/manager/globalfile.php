<?php
include '../../session.php';
include '../globalfunctions.php';
include '../global_configfunctions.php';
include 'menu.php';
?>