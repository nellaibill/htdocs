<?php
//connect mysql database
$con = mysqli_connect('localhost','lakshmih_admin','admin','lakshmih_daybook');
?>