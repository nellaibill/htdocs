<?php
//include '../reception/css/commoncssjs.html';
include 'globalfile.php';
setControlProperties ();
if (isset ( $_POST ['save'] )) {
	DataProcess ( "S" );
}elseif (isset ( $_POST ['edit'] )) {
	DataFetch ( $_POST ['enrollmentno']);
}elseif (isset ( $_POST ['editdate'] )) {
	DataFetchDate ( $_POST ['date']);
} elseif (isset ( $_POST ['delete'] )) {
	DataProcess ( "D" );
} elseif (isset ( $_POST ['update'] )) {
	DataProcess ( "U" );
} 
 elseif (isset ( $_POST ['previous'] )) {

DataFetch ( $_POST ['enrollmentno']-1 );

} elseif (isset ( $_POST ['next'] )) {
	DataFetch ( $_POST ['enrollmentno']+1 );
}
else {
	NewEntry ();
GetMaxIdNo ();
}
function setControlProperties() {
	$xIdno;
	$xDate;
	$GLOBALS ['xName'] = "";
	$GLOBALS ['xMobileNo'] = "";
	$GLOBALS ['xSubGroupNo'] = "";
$GLOBALS ['xAddress'] = "";
}

function NewEntry() {
	DataClear ();
}
function GetMaxIdNo() {
	$result = mysql_query ( "SELECT MAX(txno)+1 as txno FROM phonebook" ) or die ( mysql_error () );
	while ( $row = mysql_fetch_array ( $result ) ) {
		$GLOBALS ['xIdno'] = $row ['txno'];
		$GLOBALS ['xMaxId'] = $row ['txno'];
	}
}
function DataClear() {
	$GLOBALS ['xName'] = "";
	$GLOBALS ['xMobileNo'] = "";
	$GLOBALS ['xSubGroupNo'] = "";
$GLOBALS ['xAddress'] = "";
}
function DataFetch($xTxno) {
$result = mysql_query ( "SELECT *  FROM phonebook where txno=$xTxno" ) or die ( mysql_error () );
$count = mysql_num_rows($result);
if($count>0){
while ( $row = mysql_fetch_array ( $result ) ) {
$GLOBALS ['xIdno'] = $row ['txno'];
$GLOBALS ['xName'] = $row ['name'];
$GLOBALS ['xMobileNo'] = $row ['mobileno'];
$GLOBALS ['xSubGroupNo'] = $row ['subgroupno'];
$GLOBALS ['xAddress'] = $row ['address'];
findgroupname($row ['subgroupno']);
}
}
}

function findgroupname($xsubgroupno)
{
$result = mysql_query ( "SELECT *  FROM pb_subgroup where subgroupno=$xsubgroupno" ) or die ( mysql_error () );
while ( $row = mysql_fetch_array ( $result ) ) 
{
 $GLOBALS ['xSubGroupName'] = $row ['subgroupname'];
}
}
function DataProcess($xMode) {
$xTxno = $_POST ['enrollmentno'];
$xName= $_POST ['name'];
$xMobileNo= $_POST ['mobileno'];
$xSubGroupNo= $_POST ['subgroupno'];
$xAddress= $_POST ['address'];
if ($xMode == 'S') {
mysql_query ( "INSERT INTO phonebook VALUES ($xTxno ,'$xName','$xAddress',$xMobileNo,$xSubGroupNo)") or die ( mysql_error () );
$xMsg="Inserted";
} 
elseif ($xMode == 'U')
{
mysql_query ("UPDATE phonebook SET  name='$xName',address='$xAddress',mobileno=$xMobileNo,subgroupno=$xSubGroupNo WHERE txno=$xTxno") or die ( mysql_error () );
$xMsg="Updated";
} 
elseif ($xMode == 'D') 
{
mysql_query ("DELETE FROM phonebook WHERE txno=$xTxno") or die ( mysql_error () );
$xMsg="Deleted";
}
echo "Records ". $xMsg;
GetMaxIdNo();

//TO REFRESH PAGE
if(isset($_POST['save'])||isset($_POST['update'])||isset($_POST['delete']))
    {
    header("Location: http://technicalhspt.org/phonebook/index.php");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PHONE BOOK</title>
<style type="text/css">
body {
background-color:lightgray
	
}
textarea {
   resize: none;

}
</style>


<script>

function checkAvailability() {
jQuery.ajax({
url: "checkmobileno_availability.php",
data:'mobileno='+$("#mobileno").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
},
error:function (){}
});
}

function validateForm() {
 var xName= document.forms["phonebook"]["name"].value;
    var xMobileNo = document.forms["phonebook"]["mobileno"].value;
 var xGroupName= document.forms["phonebook"]["subgroupno"].value;


 if (xName== null || xName== "") {
        alert("Name must be filled out");
document.phonebook.name.focus();
        return false;
    }
    if (xMobileNo  == null || xMobileNo  == "") {
        alert("MobileNo must be filled out");
document.phonebook.mobileno.focus();
        return false;
    }
  if (xGroupName== null || xGroupName== "") {
        alert("GroupName must be filled out");
document.phonebook.subgroupno.focus();

        return false;
    }
}
</script>

</head>
<body onload='document.phonebook.name.focus()'>
	<div>
<center><h3 id="headertext"> PHONE BOOK-ENTRY </h3></center>
		<form class="form" name="phonebook"  action="<?php echo $_SERVER['PHP_SELF']; ?>"
			method="post">

			<fieldset>
				<div>
				
					<input type="submit" type="button" id="xPrevious" name="previous"
						class="btn btn-primary" value="PREVIOUS"
						onclick="SetEnableDisable()"> <input type="submit" type="button"
						id="xNext" name="next" class="btn btn-primary" value="NEXT"
						onclick="SetEnableDisable()">

				</div></br>
                 <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3">UNIQUE NO</label>
					<div class="col-xs-2">
						<input type="text" class="form-control" id="xIdNo"
							name="enrollmentno" value="<?php echo $GLOBALS ['xIdno']; ?>"
							placeholder="">
							 </div>
							<input type="submit" type="button" name="edit"
						class="btn btn-primary" value="EDIT">
		                 
				</div>
				
	
                <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3">NAME</label>
					<div class="col-xs-4">

						<input type="text" class="form-control" id="txtAdvance" name="name" 
							value="<?php echo $GLOBALS ['xName']; ?>" placeholder="" >
					</div>

				</div>

	</br></br>


                <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3">ADDRESS</label>
					<div class="col-xs-4" style="text-align: left;"><textarea class="form-control" rows="3" cols="15"  id="address" name="address" style="float:right"><?php echo $GLOBALS ['xAddress']; ?></textarea>
					
					</div>

				</div>

	</br></br></br></br>
	
                                  <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3">MOBILE NO</label>
					<div class="col-xs-4">

						<input type="text" class="form-control" id="mobileno" name="mobileno" onBlur="checkAvailability()"
							value="<?php echo $GLOBALS ['xMobileNo']; ?>" placeholder="" ><span id="user-availability-status"></span>   
					</div>
				</div>
	</br></br>


	
                                  <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3">GROUP NAME</label>
					<div class="col-xs-4">

<select class="form-control" id="subgroupno" value="" name="subgroupno">
						<?php

$result = mysql_query("SELECT *  FROM pb_subgroup");

echo "<option value=''>Select Your Group</option>";

while($row = mysql_fetch_array($result))

  {
?>
      <option value = "<?php echo $row['subgroupno']; ?>" 
            <?php
                if ($row['subgroupname']== $GLOBALS ['xSubGroupName']){
                    echo 'selected="selected"';
                } 
            ?> >
            <?php echo $row['subgroupname']; ?> 
            </option>
<?
  }
  echo "</select>";

?>
				</div>
				</div>
	</br>
		<div>
					<input type="submit" type="button" name="new"
						class="btn btn-primary" value="NEW" > <input type="submit"
						type="button" name="save" class="btn btn-primary" value="SAVE" onclick="return validateForm()"> <input
						type="submit" type="button" name="delete" class="btn btn-primary"
						value="DELETE"> <input type="submit" type="button" name="update"
						class="btn btn-primary" value="UPDATE">
                                               
						
				</div>
			</fieldset>
		</form>
	</div>
</body>
</html>