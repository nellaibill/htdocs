<?php
include('globalfile.php');
//include('../config/config.php');
//include('menu.php');
if($login_session=="admin")
{
$xFromDate=$GLOBALS ['xFromDate'];
$xToDate=$GLOBALS ['xToDate'];
}
else
{
$xFromDate=$GLOBALS ['xCurrentDate'];
$xToDate=$GLOBALS ['xCurrentDate'];
}
$GLOBALS ['xCurrentDate']=date('Y-m-d');
?>
<html>
<title> VIEW -OUT-GOINGCALLS</TItle>
<head><link href="bootstrap.css" rel="stylesheet">
<link href="css/reportstyle.css" rel="stylesheet">
</head>
<form action="hr001outgoingcalls.php" method="post">
<center><h3 id="headertext"> VIEW -OUT-GOINGCALLS</h3></center>
<h3>

</form>
<br>
<br>
<body>
<div id="divToPrint" >
  <div class="container">

<table class="table table-hover" border="1" >
 <thead>
    <tr>
           <th width="5%"> TXNO</th>
           <th width="10%"> DATE </th>
           <th width="10%"> FROM WHOM</th>
           <th width="10%">TO WHOM</th>
           <th width="10%">MOBILE NO</th>
   </tr>
 </thead>
 <tbody>
 <?php
  $total=0;
  $xQry="SELECT txno,date ,departmentno,towhom,contactno  from pb_outgoingcalls WHERE date >= '".$xFromDate."' 
		 AND date<= '".$xToDate."'  order by txno; "; 
  $result2=mysql_query($xQry);
  echo '<b>'; 
  echo  " Records Displaying FROM $xFromDate TO $xToDate  AT ". date(" Y-m-d h:i:sa");
  echo '</br>'; 
  echo '</b>'; 
 while ($row = mysql_fetch_array($result2)) {
 echo '<tr>';
 echo '<td>' . $row['txno']  . '</td>';
 echo '<td>' . $row['date']  . '</td>';
 finddepartmentname($row['departmentno']);
 echo '<td>' .  $GLOBALS ['xEmpDepartment'] . '</td>';
 echo '<td>' . $row['towhom']  . '</td>';
 echo '<td>' . $row['contactno']  . '</td>';
 $total+= $row['name'] ;
 echo '</tr>'; 
}
?>	
</tbody>
</table>	
  </div><!-- /container -->
</div>
</body></html>	