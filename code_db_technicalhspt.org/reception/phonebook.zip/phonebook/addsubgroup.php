<?php
include 'globalfile.php';
setControlProperties ();
$xMode = 'S';
if (isset ( $_POST ['save'] )) {
	DataProcess ( "S" );
}elseif (isset ( $_POST ['edit'] )) {
	DataFetch ( $_POST ['subgroupno']);
} elseif (isset ( $_POST ['delete'] )) {
	DataProcess ( "D" );
} elseif (isset ( $_POST ['update'] )) {
	DataProcess ( "U" );
}  elseif (isset ( $_POST ['previous'] )) {
DataFetch ( $_POST ['subgroupno']-1 );
} elseif (isset ( $_POST ['next'] )) {
	DataFetch ( $_POST ['subgroupno']+1 );
}
else {
	NewEntry ();
GetMaxIdNo ();
}
function setControlProperties() {
	$xIdno;
        $GLOBALS ['xsubgroupname'] = "";
$GLOBALS ['xundergroupno'] = "";

}

function NewEntry() {
	DataClear ();
}
function GetMaxIdNo() {
$sql="SELECT  CASE WHEN max(subgroupno)IS NULL OR max(subgroupno)= '' 
       THEN '1' 
       ELSE max(subgroupno)+1 END AS txno
FROM pb_subgroup";

	$result = mysql_query ( $sql ) or die ( mysql_error () );
	while ( $row = mysql_fetch_array ( $result ) ) {
		$GLOBALS ['xIdno'] = $row ['txno'];
		$GLOBALS ['xMaxId'] = $row ['txno'];
	}
}
function DataClear() {
	$GLOBALS ['xsubgroupname'] = "";
}
function findgroupname($xundergroupno)
{
	$result = mysql_query ( "SELECT *  FROM pb_group where groupno=$xundergroupno" ) or die ( mysql_error () );
	
	while ( $row = mysql_fetch_array ( $result ) ) {

	        $GLOBALS ['xGroupName'] = $row ['groupname'];
			}
}
function DataFetch($xTxno) {
$xMode == 'U';
		$result = mysql_query ( "SELECT *  FROM pb_subgroup where subgroupno=$xTxno" ) or die ( mysql_error () );
	$count = mysql_num_rows($result);
	if($count>0){
	while ( $row = mysql_fetch_array ( $result ) ) {

	        $GLOBALS ['xIdno'] = $row ['subgroupno'];
		$GLOBALS ['xsubgroupname'] = $row ['subgroupname'];
		$GLOBALS ['xundergroupno'] = $row ['undergroupno'];
                findgroupname($row ['undergroupno']);
	}
	}
}

function DataProcess($xMode) {

                $xTxno = $_POST ['subgroupno'];
		$xsubgroupname= $_POST ['subgroupname'];
$xundergroupno= $_POST ['undergroupno'];


if ($xMode == 'S') {

$sql = "INSERT INTO pb_subgroup VALUES ($xTxno ,'$xsubgroupname',$xundergroupno)";
$retval = mysql_query ( $sql, $con );
		if (! $retval) {
			die ( 'Could not enter data: ' . mysql_error () );
		}
		GetMaxIdNo();
		echo "     ----------Entered data successfully -----------------\n";
		mysql_close ( $con );
	} 
	elseif ($xMode == 'U') {
	$xDate = $_POST ['date'];
                $sql = "UPDATE pb_subgroup SET  subgroupname='$xsubgroupname',undergroupno= $xundergroupno WHERE subgroupno=$xTxno";
	        $retval = mysql_query ( $sql, $con );
		if (! $retval) {
			die ( 'Tx.No Not Found: ' . mysql_error () );
		}
		$GLOBALS ['xIdno']=$IdNo;
		echo "Records Updated successfully\n";
		mysql_close ( $con );
	} elseif ($xMode == 'D') {
		
		$sql = "DELETE FROM pb_subgroup WHERE subgroupno=$xTxno";
		
		$retval = mysql_query ( $sql, $con );
		if (! $retval) {
			die ( 'Tx.No Not Found: ' . mysql_error () );
		}
		$GLOBALS ['xIdno']=$IdNo;//Temp Solution
		
		echo "Records Deleted successfully\n";
		mysql_close ( $con );
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PHONE BOOK</title>
<style type="text/css">
body {
background-color:lightgray
}
</style>
</head>
<body onload='document.addsubgroup.subgroupname.focus()'>
<div>
<center><h3 id="headertext">MASTER SUB -GROUP</h3></center>
		<form class="form" name="addsubgroup" action="<?php echo $_SERVER['PHP_SELF']; ?>"
			method="post">
<fieldset>
<div>
				
					<input type="submit" type="button" id="xPrevious" name="previous"
						class="btn btn-primary" value="PREVIOUS"
						onclick="SetEnableDisable()"> <input type="submit" type="button"
						id="xNext" name="next" class="btn btn-primary" value="NEXT"
						onclick="SetEnableDisable()">

				</div></br>
                 <div class="form-group">
					<label  class="control-label col-xs-3">GROUP NO</label>
					<div class="col-xs-2">
						<input type="text" class="form-control" id="xIdNo"
							name="subgroupno" value="<?php echo $GLOBALS ['xIdno']; ?>"
							placeholder="">
							 </div>
							<input type="submit" type="button" name="edit"
						class="btn btn-primary" value="EDIT">
		                 
				</div>
				
	
                <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3"> SUB-GROUP NAME</label>
					<div class="col-xs-4">
						<input type="text" class="form-control"  name="subgroupname" 
							value="<?php echo $GLOBALS ['xsubgroupname']; ?>" placeholder="" >
					</div>

				</div>
	</br></br>

  <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3">CHOOSE MAIN GROUP</label>
					<div class="col-xs-4">

<select class="form-control" id="undergroupno" value="" name="undergroupno"
								>
						<?php

$result = mysql_query("SELECT *  FROM pb_group");

echo "<option value=''>Select Your Group</option>";

while($row = mysql_fetch_array($result))

  {
 // echo "<option value='" . $row['groupno'] . "' >" . $row['groupname'] . "</option>";
?>
      <option value = "<?php echo $row['groupno']; ?>" 
            <?php
                if ($row['groupname']== $GLOBALS ['xGroupName']){
                    echo 'selected="selected"';
                } 
            ?> >
            <?php echo $row['groupname']; ?> 
            </option>
<?

  }
  echo "</select>";
?>
					</div>
				</div>
	</br></br>
				<div>
					<input type="submit" type="button" name="new"
						class="btn btn-primary" value="NEW" > <input type="submit"
						type="button" name="save" class="btn btn-primary" value="SAVE"> <input
						type="submit" type="button" name="delete" class="btn btn-primary"
						value="DELETE"> <input type="submit" type="button" name="update"
						class="btn btn-primary" value="UPDATE">
                                               
						
				</div>
			</fieldset>
		</form>
	</div>
</body>
</html>