<?php
include 'globalfile.php';
setControlProperties ();

if (isset ( $_POST ['save'] )) {
	DataProcess ( "S" );
}elseif (isset ( $_POST ['edit'] )) {
	DataFetch ( $_POST ['groupno']);
} elseif (isset ( $_POST ['delete'] )) {
	DataProcess ( "D" );
} elseif (isset ( $_POST ['update'] )) {
	DataProcess ( "U" );
}  elseif (isset ( $_POST ['previous'] )) {
DataFetch ( $_POST ['groupno']-1 );
} elseif (isset ( $_POST ['next'] )) {
	DataFetch ( $_POST ['groupno']+1 );
}
else {
	NewEntry ();
GetMaxIdNo ();
}
function setControlProperties() {
	$xIdno;
        $GLOBALS ['xGroupName'] = "";

}

function NewEntry() {
	DataClear ();
}
function GetMaxIdNo() {
$sql="SELECT  CASE WHEN max(groupno)IS NULL OR max(groupno)= '' 
       THEN '1' 
       ELSE max(groupno)+1 END AS txno
FROM pb_group";

	$result = mysql_query ( $sql ) or die ( mysql_error () );
	while ( $row = mysql_fetch_array ( $result ) ) {
		$GLOBALS ['xIdno'] = $row ['txno'];
		$GLOBALS ['xMaxId'] = $row ['txno'];
	}
}
function DataClear() {
	$GLOBALS ['xGroupName'] = "";
}
function DataFetch($xTxno) {
		$result = mysql_query ( "SELECT *  FROM pb_group where groupno=$xTxno" ) or die ( mysql_error () );
	$count = mysql_num_rows($result);
	if($count>0){
	while ( $row = mysql_fetch_array ( $result ) ) {

	        $GLOBALS ['xIdno'] = $row ['groupno'];
		$GLOBALS ['xGroupName'] = $row ['groupname'];
	}
	}
}

function DataProcess($xMode) {

                $xTxno = $_POST ['groupno'];
		$xGroupName= $_POST ['groupname'];

if ($xMode == 'S') {

$sql = "INSERT INTO pb_group VALUES ($xTxno ,'$xGroupName')";
$retval = mysql_query ( $sql, $con );
		if (! $retval) {
			die ( 'Could not enter data: ' . mysql_error () );
		}
		GetMaxIdNo();
		echo "     ----------Entered data successfully -----------------\n";
		mysql_close ( $con );
	} 
	elseif ($xMode == 'U') {
	$xDate = $_POST ['date'];

                $sql = "UPDATE pb_group SET  groupname='$xGroupName' WHERE groupno=$xTxno";
	        $retval = mysql_query ( $sql, $con );
		if (! $retval) {
			die ( 'Tx.No Not Found: ' . mysql_error () );
		}
		$GLOBALS ['xIdno']=$IdNo;
		echo "Records Updated successfully\n";
		mysql_close ( $con );
	} elseif ($xMode == 'D') {

		$sql = "DELETE FROM pb_group WHERE groupno=$xTxno";
		
		$retval = mysql_query ( $sql, $con );
		if (! $retval) {
			die ( 'Tx.No Not Found: ' . mysql_error () );
		}
		$GLOBALS ['xIdno']=$IdNo;//Temp Solution
		
		echo "Records Deleted successfully\n";
		mysql_close ( $con );
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PHONE BOOK</title>
</head>
<body onload='document.addgroup.groupname.focus()'>
<div>
<center><h3 id="headertext">MASTER-GROUP</h3></center>
		<form class="form" name="addgroup" action="<?php echo $_SERVER['PHP_SELF']; ?>"
			method="post">

			<fieldset>
<div>
				
					<input type="submit" type="button" id="xPrevious" name="previous"
						class="btn btn-primary" value="PREVIOUS"
						onclick="SetEnableDisable()"> <input type="submit" type="button"
						id="xNext" name="next" class="btn btn-primary" value="NEXT"
						onclick="SetEnableDisable()">

				</div></br>
                 <div class="form-group">

					<label  class="control-label col-xs-3">GROUP NO</label>
					<div class="col-xs-2">
						<input type="text" class="form-control" id="xIdNo"
							name="groupno" value="<?php echo $GLOBALS ['xIdno']; ?>"
							placeholder="">
							 </div>
							<input type="submit" type="button" name="edit"
						class="btn btn-primary" value="EDIT">
		                 
				</div>
				
	
                <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-3">GROUP NAME</label>
					<div class="col-xs-4">
						<input type="text" class="form-control"  name="groupname" 
							value="<?php echo $GLOBALS ['xGroupName']; ?>" placeholder="" >
					</div>
				</div>
	</br></br>
				<div>
					<input type="submit" type="button" name="new"
						class="btn btn-primary" value="NEW" > <input type="submit"
						type="button" name="save" class="btn btn-primary" value="SAVE"> <input
						type="submit" type="button" name="delete" class="btn btn-primary"
						value="DELETE"> <input type="submit" type="button" name="update"
						class="btn btn-primary" value="UPDATE">
                                               
						
				</div>
			</fieldset>
		</form>
	</div>
</body>
</html>