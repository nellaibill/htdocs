<?php
include '../config/config.php';
include 'menu.php';
include '../reception/css/commoncssjs.html';
setControlProperties ();
if (isset ( $_POST ['save'] )) {
	DataProcess ( "S" );
}elseif (isset ( $_POST ['edit'] )) {
	DataFetch ( $_POST ['txno']);
} elseif (isset ( $_POST ['delete'] )) {
	DataProcess ( "D" );
} elseif (isset ( $_POST ['update'] )) {
	DataProcess ( "U" );
}  elseif (isset ( $_POST ['previous'] )) {
DataFetch ( $_POST ['txno']-1 );
} elseif (isset ( $_POST ['next'] )) {
	DataFetch ( $_POST ['txno']+1 );
}
else {
	NewEntry ();
GetMaxIdNo ();
}
function setControlProperties() {
DataClear();
}

function NewEntry() {
	DataClear ();
	
}
function GetMaxIdNo() {
$sql="SELECT  CASE WHEN max(txno)IS NULL OR max(txno)= '' 
       THEN '1' 
       ELSE max(txno)+1 END AS txno
FROM pb_outgoingcalls";
	$result = mysql_query ( $sql ) or die ( mysql_error () );
	while ( $row = mysql_fetch_array ( $result ) ) {
		$GLOBALS ['xIdno'] = $row ['txno'];

	}
}
function DataClear() {
$GLOBALS ['xIdno'] = "";
	$GLOBALS ['xDate']="";
	$GLOBALS ['xEmpDepartment']="";
	$GLOBALS ['xToWhom']="";
	$GLOBALS ['xContactNo']="";
}
function DataFetch($xTxno) {
		$result = mysql_query ( "SELECT *  FROM pb_outgoingcalls where txno=$xTxno" ) or die ( mysql_error () );
	$count = mysql_num_rows($result);
	if($count>0){
	while ( $row = mysql_fetch_array ( $result ) ) {
    $GLOBALS ['xIdno'] = $row ['txno'];
	$GLOBALS ['xDate']=$row ['date'];
	$GLOBALS ['xEmpDepartment']=$row ['departmentno'];
  finddepartmentname($row ['departmentno']);
	$GLOBALS ['xToWhom']=$row ['towhom'];
	$GLOBALS ['xContactNo']=$row ['contactno'];
	}
	}
}
function finddepartmentname($xNo)
{

	$result = mysql_query ( "SELECT *  FROM department where departmentno=$xNo" ) or die ( mysql_error () );
	
	while ( $row = mysql_fetch_array ( $result ) ) {

	        $GLOBALS ['xEmpDepartment'] = $row ['departmentname'];
			}
mysql_close($con);
}
function DataProcess($xMode) {
$xTxno = $_POST ['txno'];
$xDate= $_POST ['date'];
$xEmpDepartment= $_POST ['fromwhom'];
$xToWhom= $_POST ['towhom'];
$xContactNo= $_POST ['contactno'];

$xQry="";
$xMsg="";
if ($xMode == 'S') 
{
$xQry = "INSERT INTO pb_outgoingcalls VALUES ($xTxno,'$xDate',$xEmpDepartment,'$xToWhom',$xContactNo)";
$xMsg="Inserted";
} 
elseif ($xMode == 'U')
{
$xDate = $_POST ['date'];
$xQry = "UPDATE pb_outgoingcalls SET  date='$xDate',departmentno=$xEmpDepartment,towhom='$xToWhom',contactno=$xContactNo WHERE txno=$xTxno";
$xMsg="Updated";
} elseif ($xMode == 'D') 
{
$xQry = "DELETE FROM pb_outgoingcalls WHERE txno=$xTxno";
$xMsg="Deleted";
}
$retval = mysql_query ( $xQry ) or die ( mysql_error () );
if (! $retval) 
{
die ( 'Could not enter data: ' . mysql_error () );
}
GetMaxIdNo();
ShowAlert($xMsg);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>OUT-GOING CALLS</title>
 <script type="text/javascript">  
var now = new Date();

var day = ("0" + now.getDate()).slice(-2);
var month = ("0" + (now.getMonth() + 1)).slice(-2);

var today = now.getFullYear()+"-"+(month)+"-"+(day) ;

$('#datePicker').val(today);
</script>
</head>
<body onload='document.adddepartment.departmentname.focus()'>
<div>
<center><h3>OUT-GOING CALLS ENTRY</h3></center>
		<form class="form" name="adddepartment" action="<?php echo $_SERVER['PHP_SELF']; ?>"
			method="post">

			<fieldset>
<div>
				
					<input type="submit" type="button" id="xPrevious" name="previous"
						class="btn btn-primary" value="PREVIOUS"
						onclick="SetEnableDisable()"> <input type="submit" type="button"
						id="xNext" name="next" class="btn btn-primary" value="NEXT"
						onclick="SetEnableDisable()">

				</div></br>
                 <div class="form-group">

					<label  class="control-label col-xs-2">TX. NO</label>
					<div class="col-xs-2">
						<input type="text" class="form-control" id="xIdNo"
							name="txno" value="<?php echo $GLOBALS ['xIdno']; ?>"
							placeholder="">
							 </div>
							<input type="submit" type="button" name="edit"
						class="btn btn-primary" value="EDIT">
		                 
				</div>
				     
                                 <div class="form-group">
					<label  class="control-label col-xs-2">DATE</label>
					<div class="col-xs-2">
						<input type="date" class="form-control"  name="date" 
							value="<?php echo $GLOBALS ['xDate']; ?>" id="datepicker" placeholder="" >
					</div>
</div>
	 </br> </br>
                                 <div class="form-group">
					<label  class="control-label col-xs-2">FROM DEPARTMENT</label>
					<div class="col-xs-3">
					     <select class="form-control" id="" value="" name="fromwhom">
						<?php

                                            $result = mysql_query("SELECT *  FROM department");
                                            echo "<option value=''>Select Your Department</option>";
                                            while($row = mysql_fetch_array($result))
                                              {
                                                ?>
                                              <option value = "<?php echo $row['departmentno']; ?>" 
                                              <?php
                                              if ($row['departmentname']== $GLOBALS ['xEmpDepartment']){
                                               echo 'selected="selected"';
                                               } 
                                            ?> >
                                           <?php echo $row['departmentname']; ?> 
                                          </option>
                                           <?php
mysql_close($con);
                                            }
                                     echo "</select>";
                                   ?>




					</div>
				 </div></BR></BR>
                <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-2">TO WHOM</label>
					<div class="col-xs-4">
						<input type="text" class="form-control"  name="towhom" 
							value="<?php echo $GLOBALS ['xToWhom']; ?>" placeholder="" >
					</div>
				</div>
	</br></br>
	    <div class="form-group">
					<label for="lbltxno" class="control-label col-xs-2">CONTACT  NO</label>
					<div class="col-xs-2">
						<input type="text" class="form-control" maxlength="15" name="contactno" 
							value="<?php echo $GLOBALS ['xContactNo']; ?>" placeholder="" >
					</div>
				</div>
	</br></br>
				<div>
					<input type="submit" type="button" name="new"
						class="btn btn-primary" value="NEW" > <input type="submit"
						type="button" name="save" class="btn btn-primary" value="SAVE"> <input
						type="submit" type="button" name="delete" class="btn btn-primary"
						value="DELETE"> <input type="submit" type="button" name="update"
						class="btn btn-primary" value="UPDATE">
                                               
						
				</div>
			</fieldset>
		</form>
	</div>
</body>
</html>