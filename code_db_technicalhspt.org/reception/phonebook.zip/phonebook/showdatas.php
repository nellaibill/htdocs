<head>
</br>
</br>
<a href="index.php">GO TO HOME</a>
</br>
</br>
<link rel="stylesheet" type="text/css" href="css/datatable.css">
<script src="js/jquery.js"></script>
<script src="js/datatables.js"></script>
<script>
$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#example tfoot th').each( function () {
        var title = $('#example thead th').eq( $(this).index() ).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    } );
 
    // DataTable
    var table = $('#example').DataTable();
 
    // Apply the search
    table.columns().every( function () {
        var that = this;
 
        $( 'input', this.footer() ).on( 'keyup change', function () {
            that
                .search( this.value )
                .draw();
        } );
    } );
} );


</script>

<?php
include('config.php');

// sending query
$result = mysql_query("SELECT txno,(SELECT subgroupname FROM pb_subgroup as sg  where p.subgroupno=sg.subgroupno) as subgroupname ,name,address,mobileno FROM phonebook as p ");
if (!$result) {
    die("Query to show fields from table failed");
}

$fields_num = mysql_num_fields($result);
?>

<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
<tr>
<th WIDTH="10%">NO</th>
<th WIDTH="20%">GROUP</th>
<th WIDTH="20%">NAME</th>
<th WIDTH="20%">ADDRESS</th>
<th WIDTH="20%">MOBILE NUMBER</th>
</tr>
        </thead>
 
        <tfoot>
            <tr>
<th WIDTH="10%">NO</th>
<th WIDTH="20%">GROUP</th>
                               <th WIDTH="20%">NAME</th>
<th WIDTH="20%">ADDRESS</th>
                <th WIDTH="20%">MOBILE NUMBER</th>

</tr>
        </tfoot>
 
        <tbody>

<?php
/*
for($i=0; $i<$fields_num; $i++)
{
    $field = mysql_fetch_field($result);
}*/
echo "</tr>\n";
while($row = mysql_fetch_row($result))
{
    echo "<tr>";
    foreach($row as $cell)
    echo "<td>$cell</td>";
    echo "</tr>\n";
}
mysql_free_result($result);
?>