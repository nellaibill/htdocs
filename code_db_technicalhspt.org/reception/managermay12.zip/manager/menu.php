<style>
/* Header Menu Started */
 body {
        background-color: #444;
        background: url(images/bg1.jpg);
        background-repeat:no-repeat;
        background-size: 100% 100%;
         }
#container { height:70px; width: auto; margin:0 auto; }

#header { box-shadow: -1px 5px 5px -2px #333333;  position:fixed; width:100%; height:60px; border-radius:0px 0px 15px 15px; background-color:#FFF; }

#btnadd { border:1px solid #033; background: #033; border-radius:3px; height:45px; width:125px; color: #FFF; font-family:"Lucida Sans Unicode", "Lucida Grande", sans-serif; }

#footer {
	clear: both;
	background: #033;
	height: 40px;
	width: 100%;
	position: fixed;
	left: 0px;
	bottom: 0px;
	text-align: center;
	box-shadow:0px -1px 10px 1px #000;
}

#top_info { float:left; width:40px; height:40px; background: #FFF; margin:10px; border: 1px solid #CCC; }
#navbar { height:100px; clear:both; width:50%; margin:0 auto; margin-left:auto; margin-right:auto; }

/* Header Menu Ended*/

/* CSSTerm.com Simple Horizontal DropDown CSS menu */

.drop_menu {
	background:#005555;
	padding:0;
	margin:0;
	list-style-type:none;
	height:30px;
}
.drop_menu li { float:left; }
.drop_menu li a {
	padding:9px 20px;
	display:block;
	color:#fff;
	text-decoration:none;
	font:12px arial, verdana, sans-serif;
}

/* Submenu */
.drop_menu ul {
	position:absolute;
	left:-9999px;
	top:-9999px;
	list-style-type:none;
}
.drop_menu li:hover { position:relative; background:#5FD367; }
.drop_menu li:hover ul {
	left:0px;
	top:30px;
	background:#5FD367;
	padding:0px;
}

.drop_menu li:hover ul li a {
	padding:5px;
	display:block;
	width:168px;
	text-indent:15px;
	background-color:#5FD367;
}
.drop_menu li:hover ul li a:hover { background:#005555; }



/* SIDE MENU */

*      {
		margin: 0;
		padding: 0;
		font-family: 'Oswald', sans-serif;
	}
	
	body {
	    background: url(../images/colosseum.jpg) no-repeat center center fixed; 
	    -webkit-background-size: cover;
	    -moz-background-size: cover;
	    -o-background-size: cover;
	    background-size: cover;
	}
	
	.slideout-menu {
		position: fixed;
		top: 0;
		right: -250px;
		width: 250px;
		height: 100%;
		background:#A9A9A9;
		z-index: 100;
	}
	.slideout-menu h3 {
		position: relative;
		padding: 12px 10px;
		color: #fff;
		font-size: 1.2em;
		font-weight: 400;
	}
	.slideout-menu .slideout-menu-toggle {
		position: absolute;
		top: 12px;
		right: 10px;
		display: inline-block;
		padding: 6px 9px 5px;
		font-family: Arial, sans-serif;
		font-weight: bold;
		line-height: 1;
		background: #222;
		color: #999;
		text-decoration: none;
		vertical-align: top;
	}
	.slideout-menu .slideout-menu-toggle:hover {
		color: #fff;
	}
	.slideout-menu ul {
		list-style: none;
		font-weight: 300;
	
	}
	.slideout-menu ul li {
		
	}
	.slideout-menu ul li a {
		position: relative;
		display: block;
		padding: 10px;
		color: #DC143C;
		text-decoration: none;
	}
	.slideout-menu ul li a:hover {
		background: #000;
		color: #d8d8d8;
	}
	.slideout-menu ul li a i {
		position: absolute;
		top: 15px;
		right: 10px;
		opacity: .5;
	}

	
/* SIDE MENU ENDED */

</style>
<body onFocus="parent_disable();" onclick="parent_disable()";>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
    $('.slideout-menu-toggle').on('click', function(event){
    	event.preventDefault();
    	// create menu variables
    	var slideoutMenu = $('.slideout-menu');
    	var slideoutMenuWidth = $('.slideout-menu').width();
    	
    	// toggle open class
    	slideoutMenu.toggleClass("open");
    	
    	// slide menu
    	if (slideoutMenu.hasClass("open")) {
	    	slideoutMenu.animate({
		    	right: "0px"
	    	});	
    	} else {
	    	slideoutMenu.animate({
		    	right: -slideoutMenuWidth
	    	}, 250);	
    	}
    });
});
</script>
<FONT COLOR="RED" SIZE="6">
<marquee></MARQUEE></FONT>
<div id="container">
			<div id="header">
				<table cellspacing="0" width="100%" border="0" cellpadding="20px">
					<tr>
						<td width="56%">
							<table width="41%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<th scope="col"><font color="green" size="12px">L</font><span
										style="font-size: 18px;">akshmi <font color="green" size="12px">H</font>ospital</span></th>
								</tr>
								
							</table>
						</td>
										
				
						<td style="font-size: 14px;">
							<table width="93%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<th scope="col">Welcome: <?php echo strtoupper($GLOBALS ['xCurrentUser'])?></th>
									<th scope="col"><?php
									$Today = date ( 'y:m:d', time () );
									$new = date ( 'l, F d, Y', strtotime ( $Today ) );
									echo $new;
									?></th>
									<th scope="col" width="20px"><a href="../../logout.php"> <input
											type="button" id="btnadd" value="Logout" 
											src="" />
									</a></th>
								</tr>
							</table>
						</td>
					</tr>

				</table>
			</div>
			</div>
<div class="slideout-menu">
	<h3>MENU<a href="#" class="slideout-menu-toggle">&times;</a></h3>
	<ul>
<font face="verdana" size="4" color="blue">
<li><a href="../hc001fromtodate.php"  onclick="basicPopup(this.href);return false">SET DATE <span class="glyphicon glyphicon-calendar" style="color:yellow"></span> </a></li>
<?php
if(($GLOBALS ['xCurrentUserRole']=='S') || ($GLOBALS ['xCurrentUser']=="admin"))
{
?>
<li><a href="hrm_hc001settings.php"  onclick="basicPopup(this.href);return false">SETTINGS</a></li>
<?
}
?>

<li><a href="" onclick="PrintDiv(); return false">PRINT <span class="glyphicon glyphicon-print" style="color:yellow" ></span></a></li>
<li><a href="" onclick="RefreshPage(); return false">REFRESH <span class="glyphicon glyphicon-refresh" style="color:yellow"></span></a></li>
</font>
	</ul>
</div>
<!--/.slideout-menu-->
<div class="drop">
<ul class="drop_menu">
<li><a href='index.php'>HOME</a></li>
<?php
if(($GLOBALS ['xCurrentUserRole']=='S') || ($GLOBALS ['xCurrentUser']=="admin"))
{
?>

<li><a href='#'>DEPARTMENT</a>
	<ul>
     <li><a href="hrm_hm001department.php">Department</a></li>
	</ul>
</li>

<li><a href='#'>Employee <span class="glyphicon glyphicon-user" style="color:yellow"></a>
	<ul>
     <li><a href="hrm_hm002employee.php">ADD EMP</a></li>
     <li><a href="hrm_hr002employee.php">V-EMP</a></li>
	</ul>
</li>

<li><a href='#'>PF ESI<span class="glyphicon glyphicon-user" style="color:yellow"></a>
	<ul>
     <li><a href="hrm_ht005_pfesi.php">ENTRY</a></li>
	</ul>
</li>
<li><a href='#'>ATTENDENCE</a>
	<ul>
     <li><a href="hrm_ht003attendence.php">ATTENDENCE</a></li>
     <li><a href="hrm_hr003attendence.php">V-ATTENDENCE</a></li>
	</ul>
</li>


<li><a href='#'>FINE</a>
<ul>
     <li><a href="hrm_ht004fine.php">FINE</a></li>
     <li><a href="hrm_hr004fine.php">V-FINE</a></li>
</ul>
</li>
<?
}
?>
<li><a href='#'>CONTRIBUTION</a>
<ul>
<li><a href="hrm_hr005_a_employercontribution.php">EMPLOYER CONT</a></li>
<li><a href="hrm_hr005_b_employeecontribution.php">EMPLOYEE CONT</a></li>
</ul>
</li>


<?php
if(($GLOBALS ['xCurrentUserRole']=='S') || ($GLOBALS ['xCurrentUser']=="admin"))
{
?>
<li><a href='#'>SALARY</a>
<ul>
     <li><a  href="hrm_hr005_c_salary.php">V-SALARY</a></li>
     <li><a href="hrm_hr005_d_cashsalary.php">CASH</a></li>
     <li><a href="hrm_hr005_e_chequesalary.php">CHEQUE</a></li>
</ul>
</li>

<?
}
?>

<li><a href="#" style="text-decoration:none;"class="slideout-menu-toggle"><i class="fa fa-bars"></i>Tools <span class="glyphicon glyphicon-th-list" style="color:yellow"> </a></li>
<li><a href="../../logout.php">Logout  - <?php echo $GLOBALS ['xCurrentUser']; ?></a></li> 
</ul>
</div>
</br></br></br></br>
</body>
</html>