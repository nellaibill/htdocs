<?php
// include_once 'header.php';
 include_once 'menu.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/homepage_admin.css" />
</head>
<body>

	<div id="bdcontainer">
		<table border="0" cellpadding="0" cellspacing="10" align="center">

			<tr>
	
						<td><a href="hrm_ht003attendence.php"><input type="button" id="attendence" /></a></td>
			</tr>
			
		</table>

	</div>

	<div id="footer">
		<table border="0" cellpadding="15px" align="center"
			style="size: 12px; font-family: 'Courier New', Courier, monospace; color: #FFF; font-size: 12px;">
			<tr>
				<td>Designed By:<a href="https://www.mohamedsaleem.co.uu">SALEEM</a>
				</td>
			</tr>
		</table>
	</div>


</body>

</html>


