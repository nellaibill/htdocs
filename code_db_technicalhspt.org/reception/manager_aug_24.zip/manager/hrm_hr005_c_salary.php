<?php
include 'globalfile.php';
$xFromDate = $GLOBALS ['xFromDate'];
$xToDate = $GLOBALS ['xToDate'];
$xEmpNo = $GLOBALS ['xEmployeeNo'];
$xDeparmentNo = $GLOBALS ['xDepartmentNo'];
$xDays = $GLOBALS ['xDays'];
$GLOBALS ['xCurrentDate'] = date ( 'Y-m-d' );
$xCurrentDate = date ( 'Y-m-d' );
$xTdsValue=0.10;
?>
<html>
<title>VIEW -SALARY</title>

<head>
<link href="bootstrap.css" rel="stylesheet">
<link href="css/reportstyle.css" rel="stylesheet">
</head>
<form action="hrm_hr005_c_salary.php" method="post">
	<body>
		<div id="divToPrint">
			<div class="panel panel-success">
				<div class="panel-heading">
					<b><h3 class="panel-title text-center"><?php echo "Salary Generated FROM [".date('d/M/y', strtotime($xFromDate))."]TO [".date('d/M/y', strtotime($xToDate))."] As On ". date("d/M/y h:i:sa"); ?></h3></b>
				</div>
				<div class="panel-body">
					<div class="container">
						<table class="table table-condensed" border="1" id="lastrow">
							<thead>
								<tr>
									<th>S.NO</th>
									<th>EMPLOYEE NAME</th>
									<th>DEPARTMENT NAME</th>
									<th>BASIC SALARY</th>
									<th>PF 12%</th>
									<th>ESI 1.75%</th>
									<th>NETSALARY</th>
									<th>INCENTIVE(L)</th>
									<th>INCENTIVE(O)</th>
									<th>DEDUCTIONS</th>

									<th>TOTAL</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>S.NO</th>
									<th>EMPLOYEE NAME</th>
									<th>DEPARTMENT NAME</th>
									<th>BASIC SALARY</th>
									<th>PF</th>
									<th>ESI</th>
									<th>NETSALARY</th>
									<th>INCENTIVE(L)</th>
									<th>INCENTIVE(O)</th>
									<th>DEDUCTIONS</th>

									<th>TOTAL</th>
								</tr>
							</tfoot>

							<tbody>

	<?php
	$xSlNo = 0;
	$xZeroValue = 0;
	$xQryFilter = '';
	/* Department No 13 Refers to Doctors they have 4 days leave */
	if ($row ['departmentno'] == 13) {
		$xLeaveCount = 4;
	} 	

	/* 8 -Manager 14 -Electrician 16-Duty Doctors [No Leave Salary ] */
	else if ($row ['departmentno'] == 8 || $row ['departmentno'] == 14 || $row ['departmentno'] == 16) {
		$xLeaveCount = 0;
	}  /* Others Having 2 Days Leave Count */
else {
		$xLeaveCount = 2;
	}
	$xLeaveIncentive = 0;
	$xDeductions = 0;
	$xTotalSalary = 0;
	$xQry = '';
	/* --------------------- Execute All Employees-------------------- */
	if ($xEmpNo == 0) {
		if ($xDeparmentNo != 0) {
			$xQryFilter = " and a.departmentno=$xDeparmentNo";
		}
		
		/* 06/nov/2015 departmentno get from employee insteadof depatment */
		
		$xQry = "SELECT SUM( 
	STATUS ) AS 
	status , e.empname, e.empdol,e.empstatus,e.empbasicsalary AS basicsalary,e.departmentno as departmentno,empfinededuction,
e.txno as empno,e.empincentive,e.empallowance,e.emppfno
	FROM  `attendence` as a , employeedetails AS e
	WHERE date >= '$xFromDate' AND date<= '$xToDate' and e.departmentno!=6
	AND e.txno = empno and (e.empdol>= '$xFromDate' or e.empstatus='ACTIVE') $xQryFilter
	GROUP BY empno
	ORDER BY departmentno,empname";
		$result2 = mysql_query ( $xQry );
		$xGrandBasicSalary = 0;
		$xGrandLeaveIncentive = 0;
		$xGrandDeductions = 0;
		$xGrandFineDeduction = 0;
		$xGrandEmpIncentiveOthers = 0;
		$xGrandTotalSalary = 0;
		$xGrandPf = 0;
		$xGrandEsi = 0;
		$xGrandNetSalary = 0;
		while ( $row = mysql_fetch_array ( $result2 ) ) {
			/* Department No 13 Refers to Doctors they have 4 days leave */
			if ($row ['departmentno'] == 13) {
				$xLeaveCount = 4;
			} 			

			/* 8 -Manager 14 -Electrician 16-Duty Doctors [No Leave Salary ] */
			else if ($row ['departmentno'] == 8 || $row ['departmentno'] == 14 || $row ['departmentno'] == 16) {
				$xLeaveCount = 0;
			}  /* Others Having 2 Days Leave Count */
else {
				$xLeaveCount = 2;
			}
			$xLeaveIncentive = 0;
			$xEmpIncentiveOthers = 0;
			$xDeductions = 0;
			$xTotalSalary = 0;
			$xBasicSalary = $row ['basicsalary'];
			$xAllowance = $row ['empallowance'];
			
			$xOneDaySalary = ($xBasicSalary + $xAllowance) / 30;
			$xLeaveCount -= $row ['status'];
			$xEmpIncentiveOthers = $row ['empincentive'];
			if ($xLeaveCount > 0) {
				/* Op-Sister Department No -9 One Day Salary Only Watch Man Added 10/01/2017-Ganesan Sir */
				if ($row ['departmentno'] == 9 || $row ['departmentno'] == 17) {
					$xLeaveIncentive = $xLeaveCount * $xOneDaySalary;
				} else {
					$xLeaveIncentive = $xLeaveCount * $xOneDaySalary * 2;
				}
			} else {
				$xDeductions = $xLeaveCount * $xOneDaySalary;
			}
			
			finddepartmentname ( $row ['departmentno'] );
			echo '<tr bgcolor="' . $GLOBALS ['xDepartmentColor'] . '">';
			echo '<td >' . $xSlNo += 1 . '</td>';
			echo '<td style=font-weight:bold>' . $row ['empname'] . '</td>';
			finddepartmentname ( $row ['departmentno'] );
			echo '<td >' . $GLOBALS ['xEmpDepartment'] . '</td>';
			echo '<td align=right>' . money_format ( "%!n", $row ['basicsalary'] ) . '</td>';
			
			$xPf = 0;
			if ($row ['emppfno'] != "")
				$xPf = ($row ['basicsalary'] * 12 / 100);
			echo '<td>' . round ( $xPf ) . '</td>';
			
			$xGrandPf += $xPf;
			
			$xEsi = 0;
			if ($row ['emppfno'] != "")
				$xEsi = ($row ['basicsalary'] * 1.75 / 100);
			echo '<td >' . round ( $xEsi ) . '</td>';
			$xGrandEsi += $xEsi;
			
			$xNetSalary = 0;
			$xTdsDeducted=0;
			
			if ($row ['departmentno'] == 13) {
				$xTdsDeducted=(($row ['basicsalary'])-($row ['basicsalary']*$xTdsValue));
				$xNetSalary = $xTdsDeducted + $row ['empallowance'] - $xPf - $xEsi;
			}
			else {
				$xNetSalary = $row ['basicsalary'] + $row ['empallowance'] - $xPf - $xEsi;
			}
			
			echo '<td align=right>' . round ( $xNetSalary ) . '</td>';
			$xGrandNetSalary += round ( $xNetSalary );
			
			$xTotalSalary = $xNetSalary + $xLeaveIncentive + $xDeductions + $xEmpIncentiveOthers;
			
			if ($row ['departmentno'] == 12) {
				echo '<td align=right>' . money_format ( "%!n", round ( $xZeroValue ) ) . '</td>';
			} else {
				echo '<td align=right>' . money_format ( "%!n", round ( $xLeaveIncentive ) ) . '</td>';
			}
			echo '<td align=right>' . money_format ( "%!n", $xEmpIncentiveOthers ) . '</td>';
			echo '<td align=right>' . money_format ( "%!n", round ( $xDeductions ) ) . '</td>';
			getemployeefineamount ( $row ['empno'], $xFromDate, $xToDate );
			// echo '<td align=right>' . money_format ( "%!n", round ( $GLOBALS ['xSingleEmployeeTotalFineAmount'] ) ) . '</td>';
			echo '<td align=right>' . money_format ( "%!n", round ( $xTotalSalary - $GLOBALS ['xSingleEmployeeTotalFineAmount'] ) ) . '</td>';
			echo '</tr>';
			$xGrandBasicSalary += $row ['basicsalary'];
			if ($row ['departmentno'] == 12) {
				$xGrandLeaveIncentive += $xZeroValue;
			} else {
				$xGrandLeaveIncentive += $xLeaveIncentive;
			}
			$xGrandDeductions += $xDeductions;
			$xGrandFineDeduction += $GLOBALS ['xSingleEmployeeTotalFineAmount'];
			$xGrandTotalSalary += $xTotalSalary;
			$xGrandEmpIncentiveOthers += $xEmpIncentiveOthers;
		}
		echo '<tr style=font-weight:bold;>';
		echo '<td> </td>';
		echo '<td> </td>';
		echo '<td> GRAND -TOTAL </td>';
		echo '<td align=right>' . money_format ( "%!n", round ( $xGrandBasicSalary ) ) . '</td>';
		echo '<td>' . money_format ( "%!n", $xGrandPf ) . '</td>';
		echo '<td>' . money_format ( "%!n", $xGrandEsi ) . '</td>';
		echo '<td>' . money_format ( "%!n", $xGrandNetSalary ) . '</td>';
		echo '<td align=right>' . money_format ( "%!n", round ( $xGrandLeaveIncentive ) ) . '</td>';
		echo '<td align=right>' . money_format ( "%!n", round ( $xGrandEmpIncentiveOthers ) ) . '</td>';
		echo '<td align=right>' . money_format ( "%!n", round ( $xGrandDeductions ) ) . '</td>';
		// echo '<td align=right>' . money_format ( "%!n", round ( $xGrandFineDeduction ) ) . ' </td>';
		echo '<td align=right>' . money_format ( "%!n", round ( $xGrandTotalSalary ) ) . ' </td>';
		echo '</tr>';
	}  /* --------------------- Execute All Employees Ended-------------------- */
	

	?>


	</tbody>


						</table>
					</div>
				</div>
			</div>
		</div>
	</body>
</form>
</html>
