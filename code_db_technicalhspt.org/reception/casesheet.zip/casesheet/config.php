<?php
setlocale(LC_MONETARY, 'en_IN');
date_default_timezone_set("Asia/Kolkata");
$con =mysql_connect("localhost", "lakshmih_admin", "admin") or die(mysql_error());
mysql_select_db("lakshmih_hms") or die(mysql_error());

?>
